package com.example.inventoryappmiller;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

// DatabaseHelper manages the SQLite database for the inventory app.
// It holds two tables: one for user logins and one for inventory items.
public class DatabaseHelper extends SQLiteOpenHelper {

    // Database file name and version.
    private static final String DATABASE_NAME = "inventory.db";
    private static final int DATABASE_VERSION = 1;

    // Users table and its columns.
    private static final String TABLE_USERS = "users";
    private static final String COL_USER_ID = "_id";
    private static final String COL_USERNAME = "username";
    private static final String COL_PASSWORD = "password";

    // Inventory table and its columns.
    private static final String TABLE_INVENTORY = "inventory";
    private static final String COL_ITEM_ID = "_id";
    private static final String COL_ITEM_NAME = "name";
    private static final String COL_ITEM_QTY = "quantity";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Create both tables when the database is first set up.
    @Override
    public void onCreate(SQLiteDatabase db) {
        String createUsers = "CREATE TABLE " + TABLE_USERS + " (" +
                COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_USERNAME + " TEXT UNIQUE, " +
                COL_PASSWORD + " TEXT)";
        db.execSQL(createUsers);

        String createInventory = "CREATE TABLE " + TABLE_INVENTORY + " (" +
                COL_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_ITEM_NAME + " TEXT, " +
                COL_ITEM_QTY + " INTEGER)";
        db.execSQL(createInventory);
    }

    // Drop and rebuild the tables if the database version changes.
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_INVENTORY);
        onCreate(db);
    }

    // ----- User account methods -----

    // Returns true if the username already exists in the users table.
    public boolean userExists(String username) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS, new String[]{COL_USER_ID},
                COL_USERNAME + " = ?", new String[]{username},
                null, null, null);
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    // Adds a new user. Returns false if the username is already taken.
    public boolean addUser(String username, String password) {
        if (userExists(username)) {
            return false;
        }
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_USERNAME, username);
        values.put(COL_PASSWORD, password);
        long result = db.insert(TABLE_USERS, null, values);
        return result != -1;
    }

    // Returns true if the username and password match a row in the users table.
    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS, new String[]{COL_USER_ID},
                COL_USERNAME + " = ? AND " + COL_PASSWORD + " = ?",
                new String[]{username, password},
                null, null, null);
        boolean match = cursor.getCount() > 0;
        cursor.close();
        return match;
    }

    // ----- Inventory item methods -----

    // Adds a new item to the inventory table and returns its new row id.
    public long addItem(String name, int quantity) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_ITEM_NAME, name);
        values.put(COL_ITEM_QTY, quantity);
        return db.insert(TABLE_INVENTORY, null, values);
    }

    // Returns every item in the inventory table as a list.
    public List<InventoryItem> getAllItems() {
        List<InventoryItem> items = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.query(TABLE_INVENTORY,
                new String[]{COL_ITEM_ID, COL_ITEM_NAME, COL_ITEM_QTY},
                null, null, null, null, COL_ITEM_NAME + " ASC");
        while (cursor.moveToNext()) {
            int id = cursor.getInt(0);
            String name = cursor.getString(1);
            int qty = cursor.getInt(2);
            items.add(new InventoryItem(id, name, qty));
        }
        cursor.close();
        return items;
    }

    // Updates the quantity of a specific item.
    public void updateQuantity(int id, int newQuantity) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_ITEM_QTY, newQuantity);
        db.update(TABLE_INVENTORY, values, COL_ITEM_ID + " = ?",
                new String[]{String.valueOf(id)});
    }

    // Removes a specific item from the inventory table.
    public void deleteItem(int id) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(TABLE_INVENTORY, COL_ITEM_ID + " = ?",
                new String[]{String.valueOf(id)});
    }
}