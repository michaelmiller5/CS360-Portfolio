package com.example.inventoryappmiller;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

// Login screen. Checks credentials against the database, and lets a
// first-time user create an account from the same screen.
public class MainActivity extends AppCompatActivity {

    private EditText editUsername;
    private EditText editPassword;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editUsername = findViewById(R.id.editUsername);
        editPassword = findViewById(R.id.editPassword);
        Button buttonLogin = findViewById(R.id.buttonLogin);
        Button buttonCreateAccount = findViewById(R.id.buttonCreateAccount);

        dbHelper = new DatabaseHelper(this);

        // Log in: check the entered credentials against the users table.
        buttonLogin.setOnClickListener(v -> {
            String username = editUsername.getText().toString().trim();
            String password = editPassword.getText().toString().trim();
            if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
                Toast.makeText(this, "Enter a username and password.",
                        Toast.LENGTH_SHORT).show();
                return;
            }
            if (dbHelper.checkUser(username, password)) {
                startActivity(new Intent(MainActivity.this, InventoryActivity.class));
            } else {
                Toast.makeText(this, "Invalid login. Try again or create an account.",
                        Toast.LENGTH_SHORT).show();
            }
        });

        // Create account: save a new username and password to the database.
        buttonCreateAccount.setOnClickListener(v -> {
            String username = editUsername.getText().toString().trim();
            String password = editPassword.getText().toString().trim();
            if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
                Toast.makeText(this, "Enter a username and password to register.",
                        Toast.LENGTH_SHORT).show();
                return;
            }
            if (dbHelper.addUser(username, password)) {
                Toast.makeText(this, "Account created. You can now log in.",
                        Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "That username already exists.",
                        Toast.LENGTH_SHORT).show();
            }
        });
    }
}