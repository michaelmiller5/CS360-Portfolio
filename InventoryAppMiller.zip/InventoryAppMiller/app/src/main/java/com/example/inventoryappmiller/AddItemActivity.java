package com.example.inventoryappmiller;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

// Screen for adding a new item. Saves the item and its starting quantity
// to the database, then returns to the grid.
public class AddItemActivity extends AppCompatActivity {

    private EditText editItemName;
    private EditText editItemQty;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        editItemName = findViewById(R.id.editItemName);
        editItemQty = findViewById(R.id.editItemQty);
        Button buttonSaveItem = findViewById(R.id.buttonSaveItem);

        dbHelper = new DatabaseHelper(this);

        // Save the new item to the database, then close this screen.
        buttonSaveItem.setOnClickListener(v -> {
            String name = editItemName.getText().toString().trim();
            String qtyText = editItemQty.getText().toString().trim();

            if (TextUtils.isEmpty(name) || TextUtils.isEmpty(qtyText)) {
                Toast.makeText(this, "Enter an item name and quantity.",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            int quantity = Integer.parseInt(qtyText);
            dbHelper.addItem(name, quantity);
            Toast.makeText(this, "Item added.", Toast.LENGTH_SHORT).show();
            finish();
        });
    }
}