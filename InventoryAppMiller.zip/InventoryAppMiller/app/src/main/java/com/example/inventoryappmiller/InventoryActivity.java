package com.example.inventoryappmiller;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

// Inventory grid screen. Loads items from the database, lets the user add,
// update, and delete them, and sends an SMS alert when an item runs out.
public class InventoryActivity extends AppCompatActivity
        implements InventoryAdapter.OnQuantityZeroListener {

    private static final int SMS_PERMISSION_CODE = 100;

    private DatabaseHelper dbHelper;
    private RecyclerView recyclerInventory;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        dbHelper = new DatabaseHelper(this);

        recyclerInventory = findViewById(R.id.recyclerInventory);
        recyclerInventory.setLayoutManager(new LinearLayoutManager(this));

        Button buttonAddItem = findViewById(R.id.buttonAddItem);
        buttonAddItem.setOnClickListener(v ->
                startActivity(new Intent(InventoryActivity.this, AddItemActivity.class)));

        // Ask for SMS permission so low-stock alerts can be sent.
        checkSmsPermission();

        loadItems();
    }

    // Reload the grid from the database each time the screen returns to front,
    // so newly added items appear.
    @Override
    protected void onResume() {
        super.onResume();
        loadItems();
    }

    // Reads all items from the database and shows them in the grid.
    private void loadItems() {
        List<InventoryItem> items = dbHelper.getAllItems();
        InventoryAdapter adapter = new InventoryAdapter(items, dbHelper, this);
        recyclerInventory.setAdapter(adapter);
    }

    // Checks for SMS permission and requests it if it has not been granted.
    private void checkSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
        }
    }

    // Shows a message based on whether the user granted or denied SMS permission.
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS alerts enabled.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "SMS alerts off. The app will still work.",
                        Toast.LENGTH_SHORT).show();
            }
        }
    }

    // Called by the adapter when an item's quantity reaches zero.
    @Override
    public void onQuantityZero(String itemName) {
        String message = "Low inventory alert: " + itemName + " has reached zero.";
        // Only send an SMS if the user granted permission. If not, the app
        // keeps working and simply does not send a notification.
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {
            try {
                SmsManager smsManager = getSystemService(SmsManager.class);
                // Placeholder destination number for the low-stock alert.
                smsManager.sendTextMessage("5556", null, message, null, null);
                Toast.makeText(this, "SMS sent: " + message, Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(this, "Could not send SMS.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}