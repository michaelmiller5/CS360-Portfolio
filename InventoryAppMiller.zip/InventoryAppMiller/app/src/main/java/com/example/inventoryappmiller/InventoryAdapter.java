package com.example.inventoryappmiller;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

// Adapter that shows each inventory item as a row in the grid. Handles
// increasing, decreasing, and deleting items, and writes every change
// back to the database.
public class InventoryAdapter extends RecyclerView.Adapter<InventoryAdapter.ViewHolder> {

    // Lets the activity react when an item's quantity reaches zero.
    public interface OnQuantityZeroListener {
        void onQuantityZero(String itemName);
    }

    private final List<InventoryItem> items;
    private final DatabaseHelper dbHelper;
    private final OnQuantityZeroListener zeroListener;

    public InventoryAdapter(List<InventoryItem> items, DatabaseHelper dbHelper,
                            OnQuantityZeroListener zeroListener) {
        this.items = items;
        this.dbHelper = dbHelper;
        this.zeroListener = zeroListener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_inventory_row, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        InventoryItem item = items.get(position);
        holder.textItemName.setText(item.getName());
        holder.textItemQty.setText(String.valueOf(item.getQuantity()));

        // Increase the quantity by one and save it to the database.
        holder.buttonPlus.setOnClickListener(v -> {
            int pos = holder.getBindingAdapterPosition();
            if (pos == RecyclerView.NO_POSITION) return;
            InventoryItem current = items.get(pos);
            int newQty = current.getQuantity() + 1;
            current.setQuantity(newQty);
            dbHelper.updateQuantity(current.getId(), newQty);
            notifyItemChanged(pos);
        });

        // Decrease the quantity by one, but never below zero, and save it.
        holder.buttonMinus.setOnClickListener(v -> {
            int pos = holder.getBindingAdapterPosition();
            if (pos == RecyclerView.NO_POSITION) return;
            InventoryItem current = items.get(pos);
            if (current.getQuantity() > 0) {
                int newQty = current.getQuantity() - 1;
                current.setQuantity(newQty);
                dbHelper.updateQuantity(current.getId(), newQty);
                notifyItemChanged(pos);
                // Alert the activity when the item runs out.
                if (newQty == 0 && zeroListener != null) {
                    zeroListener.onQuantityZero(current.getName());
                }
            }
        });

        // Delete the item from the list and the database.
        holder.buttonDelete.setOnClickListener(v -> {
            int pos = holder.getBindingAdapterPosition();
            if (pos == RecyclerView.NO_POSITION) return;
            InventoryItem current = items.get(pos);
            dbHelper.deleteItem(current.getId());
            items.remove(pos);
            notifyItemRemoved(pos);
        });
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView textItemName;
        TextView textItemQty;
        Button buttonMinus;
        Button buttonPlus;
        Button buttonDelete;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            textItemName = itemView.findViewById(R.id.textItemName);
            textItemQty = itemView.findViewById(R.id.textItemQty);
            buttonMinus = itemView.findViewById(R.id.buttonMinus);
            buttonPlus = itemView.findViewById(R.id.buttonPlus);
            buttonDelete = itemView.findViewById(R.id.buttonDelete);
        }
    }
}